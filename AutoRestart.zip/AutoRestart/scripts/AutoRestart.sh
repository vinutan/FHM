#!/usr/local/bin/bash
#
#
set +x
APP=$1

HOST=`hostname`
Date=`date "+%d-%m-%Y_%H-%M-%S"`
DATE=`date "+%d-%m-%Y"`

SCR_BIN=/apps/tibco/bin
SCR_HOME=$SCR_BIN/AutoRestart
SCR=$SCR_HOME/scripts
INPUT=$SCR_HOME/input
BATCH=$SCR_HOME/input/$APP
EMAIL_TEMP=$SCR_HOME/input/EmailTemplates
LOGS=$SCR_HOME/logs/$APP

LogFile=$LOGS/AutoRestart_"$APP"_"$HOST"_"$Date".log
LogName=AutoRestart_"$APP"_"$HOST"_"$Date".log

TO_PRIMS="AIMS.MW.Tibco@sanofi.com"
CC="vinutan.naik@sanofi.com,AIMS.MW.Tibco@sanofi.com"
FROM="EAI.Admin.CGZ@noreply.com"

Subject_Failure="Applications Restart script errored out | $APP | $HOST | $DATE"
Subject_Success="Applications Restart script execution completed | $APP | $HOST | $DATE"

Body_Success="`cat $EMAIL_TEMP/AppScriptSuccess/AppScriptSuccess.html`"
Body_Failure="`cat $EMAIL_TEMP/AppScriptError/AppScriptError.html`"

exec >> $LogFile 2>&1

if [ ! -d "$LOGS" ]
then
        mkdir -p $LOGS
fi

if [ -f "$SCR_BIN/setenv.sh" ]
then
        . $SCR_BIN/setenv.sh
else
        echo "$(date '+[%d/%m/%Y %H:%M:%S]') setenv.sh NOT Found. Exiting the script..."
        $SCR/SendMail_AR.sh "$TO_PRIMS" "$CC" "$FROM" "$Subject_Failure" "$LogName" "$LogFile" "$Body_Failure"
        exit
fi

export AppDomain_Temp=${APP}_DOMAIN
AppDomain=`echo "${!AppDomain_Temp}"`

export TO_TEMP=${APP}_EMAIL
TO=`echo "${!TO_TEMP}"`

if [ ! -d "$BATCH" ]
then
        echo "$(date '+[%d/%m/%Y %H:%M:%S]') Important directory for this script namely $BATCH NOT Found. Exiting the script..."
        $SCR/SendMail_AR.sh "$TO" "$CC" "$FROM" "$Subject_Failure" "$LogName" "$LogFile" "$Body_Failure"
        exit
fi

if [ -s "$BATCH/AppManage.$APP" ]
then
	> "$BATCH"/"$APP"_running.lst
	head -n $(( $(wc -l $BATCH/AppManage.$APP | awk '{print $1}') - 1 )) $BATCH/AppManage.$APP | tail -n +4 | cut -d "\"" -f 2 | awk 'BEGIN {FS ="/"} {print $NF}' > "$BATCH"/"$APP"_running.lst
        head -3 $BATCH/AppManage.$APP > "$BATCH"/AppManage."$APP"_running_unique
        echo -en "File Started at $Date:\n\n" > "$BATCH"/"$APP"_stopped.lst
        head -3 $BATCH/AppManage.$APP > "$BATCH"/AppManage."$APP"_stopped

	> "$BATCH"/AppManage."$APP"_running
	head -n $(( $(wc -l $BATCH/AppManage.$APP | awk '{print $1}') - 1 )) $BATCH/AppManage.$APP | tail -n +4 > "$BATCH"/AppManage."$APP"_running
        cat "$BATCH"/AppManage."$APP"_running | sort |uniq >> "$BATCH"/AppManage."$APP"_running_unique
        tail -1 $BATCH/AppManage.$APP >> "$BATCH"/AppManage."$APP"_running_unique
        tail -1 $BATCH/AppManage.$APP >> "$BATCH"/AppManage."$APP"_stopped
        cp "$BATCH"/AppManage."$APP"_running_unique $INPUT/AppManage.batch

        echo -en "$(date '+[%d/%m/%Y %H:%M:%S]')Applications for which Restart action is being initiated:\n"
        cat "$BATCH"/AppManage."$APP"_running | sort |uniq | sed -e "s/<app name=\"//g" | sed -e "s/\"\/>//g"
        echo -en "\n\n"
	
	if [ -s "$BATCH"/AppManage."$APP"_running_unique ]
	then
		$TRA_BIN/AppManage -batchstop -domain $AppDomain -cred $CONFIG/cred_$APP -dir $INPUT/
		echo -en "$(date '+[%d/%m/%Y %H:%M:%S]') Sleeping for 30 seconds before checking if all the provided services under $APP are stopped.\n\n"
		sleep 30
	fi

        while read BW
        do
                BW_Count=`$PSU | grep -i $APP | grep -i $BW | grep -v grep | wc -l`

                if [ "$BW_Count" -gt 0 ]
                then
                        echo "$(date '+[%d/%m/%Y %H:%M:%S]') - WARN : $BW is still running. Initiating hard kill for this Application."
                        PID=`$PSU | grep -i $APP | grep -i $BW | grep -v grep | awk 'BEGIN {FS =" "} {print $2}'`
			kill -9 $PID
                        sleep 3

                        BW_Count_new=`$PSU | grep -i $APP | grep -i $BW | grep -v grep | wc -l`

                        if [ "$BW_Count_new" -eq 0 ]
                        then
                                echo -en "$(date '+[%d/%m/%Y %H:%M:%S]') - INFO : $BW has been hard killed successfully.\n\n"
                        else
                                echo -en "$(date '+[%d/%m/%Y %H:%M:%S]') - ERROR : Unable to stop $BW using Hard Kill option and it is still running. Please check it manually.\n\n"
                        fi
                fi
        done < "$BATCH"/"$APP"_running.lst

	echo -en "\n\n"
        echo -en "$(date '+[%d/%m/%Y %H:%M:%S]') Sleeping for 30 seconds before intiating the Start operation for provided services under $APP.\n"
        sleep 30

        if [ -s "$INPUT/AppManage.batch" ]
        then
                echo -en "$(date '+[%d/%m/%Y %H:%M:%S]') Initiating the start operation for $APP applications.\n"
                $TRA_BIN/AppManage -batchstart -domain $AppDomain -cred $CONFIG/cred_$APP -dir $INPUT/
		echo -en "$(date '+[%d/%m/%Y %H:%M:%S]') Sleeping for 30 seconds before checking the engines startup.\n"
                sleep 30
        else
                echo "$(date '+[%d/%m/%Y %H:%M:%S]') \'AppManage.batch\' can't be located or is empty... Kindly check manually."
                $SCR/SendMail_AR.sh "$TO" "$CC" "$FROM" "$Subject_Failure" "$LogName" "$LogFile" "$Body_Failure"
                exit
        fi

        while read BW
        do
                BW_Count=`$PSU | grep -i $APP | grep -i $BW | grep -v grep | wc -l`

                if [ "$BW_Count" -eq 0 ]
                then
                        echo -en "$(date '+[%d/%m/%Y %H:%M:%S]') - WARN : $BW was not started back up or it is deployed on a server other than $HOST. Kindly verify manually.\n"
                fi
        done < "$BATCH"/"$APP"_running.lst
	echo -en "\n\n"

else
        echo "$(date '+[%d/%m/%Y %H:%M:%S]') AppManage.$APP NOT Found. Exiting the script..."
        $SCR/SendMail_AR.sh "$TO" "$CC" "$FROM" "$Subject_Failure" "$LogName" "$LogFile" "$Body_Failure"
        exit
fi

echo "$(date '+[%d/%m/%Y %H:%M:%S]') - Script execution completed. Exiting the script..."
echo "-------------------------------------------------------------------------------------------------------------------"
echo "-------------------------------------------------------------------------------------------------------------------"
echo "-------------------------------------------------------------------------------------------------------------------"
$SCR/SendMail_AR.sh "$TO" "$CC" "$FROM" "$Subject_Success" "$LogName" "$LogFile" "$Body_Success"
exit
