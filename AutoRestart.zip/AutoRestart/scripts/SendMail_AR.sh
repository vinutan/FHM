#!/usr/local/bin/bash
#
#
SCR_BIN=/software/tibco/bin
export SANOFI="$SCR_BIN/AutoRestart/input/EmailTemplates/images/Sanofi.png"
export ACN="$SCR_BIN/AutoRestart/input/EmailTemplates/images/Cognizant.png"
export MAIL="$SCR_BIN/AutoRestart/input/EmailTemplates/images/Mail.png"
mail_boundary="$(uuidgen)/$(hostname)"
echo "To: $1
CC: $2
From: $3
Subject: $4
Content-Type: multipart/mixed; boundary=\"$mail_boundary\"
MIME-Version: 1.0

--$mail_boundary
Content-Transfer-Encoding: base64
Content-Type: application/octet-stream; name=$5
Content-Disposition: attachment; filename=$5

`openssl base64 < $6`

--$mail_boundary
Content-Type: text/html; charset="US-ASCII"
Content-Disposition: inline

$7

--$mail_boundary
Content-Type: image/png; name=$(basename $SANOFI)
Content-Disposition: inline; filename="$(basename $SANOFI)"
Content-Transfer-Encoding: base64
Content-ID: <image001.png>

`openssl base64 < $SANOFI`

--$mail_boundary
Content-Type: image/png; name=$(basename $ACN)
Content-Disposition: inline; filename="$(basename $ACN)"
Content-Transfer-Encoding: base64
Content-ID: <image002.png>

`openssl base64 < $ACN`

--$mail_boundary
Content-Type: image/png; name=$(basename $MAIL)
Content-Disposition: inline; filename="$(basename $MAIL)"
Content-Transfer-Encoding: base64
Content-ID: <image003.png>

`openssl base64 < $MAIL`

--$mail_boundary--" | /usr/sbin/sendmail -t
