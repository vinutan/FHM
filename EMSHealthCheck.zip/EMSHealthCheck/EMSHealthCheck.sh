#!/bin/sh
#####################################################################################
#####################################################################################
#####################################################################################
#####################################################################################
############################Authored By : Anny M.####################################
########################Released On : October 3, 2017################################
#####################################################################################
#####################################################################################
#####################################################################################
#####################################################################################
#
#
#
#
#
#
export MY_HOME=/apps/tibco/bin/EMSHealthCheck
export SCR=${MY_HOME}/scripts
export CFG=${MY_HOME}/config
export TMP=${MY_HOME}/tmp


echo "Initializing EMS Health Check Sript"
prompt="Pick the EMS for which you want to perform the health check :"
options=("App EMS for HRGS" "App EMS for HRGD" "App EMS for HRGT" "App EMS for HRGP" "Standalone EMS" "EMS FT Pair")

PS3="$prompt"
select opt in "${options[@]}" "Quit"; do 

    case "$REPLY" in

    1 ) echo "You picked option $REPLY to perform the health check for $opt"
	export $(cat ${CFG}/HRGS.cfg | xargs)
	${SCR}/Operations.sh
	;;	
    2 ) echo "You picked option $REPLY to perform the health check for $opt"
	export $(cat ${CFG}/HRGD.cfg | xargs)
        ${SCR}/Operations.sh
        ;;
    3 ) echo "You picked option $REPLY to perform the health check for $opt"
	export $(cat ${CFG}/HRGT.cfg | xargs)
        ${SCR}/Operations_FT.sh
	;;
    4 ) echo "You picked option $REPLY to perform the health check for $opt"
	export $(cat ${CFG}/HRGP.cfg | xargs)
        ${SCR}/Operations_FT.sh
	;;
    5 ) echo "You picked option $REPLY to perform the health check for $opt"
	read -p 'Enter the domain/environment name : ' env
	echo "env="$env"" >> ${CFG}/Standalone.cfg

	read -p 'Enter the EMS URL : ' EMS
	echo "EMS="$EMS"" >> ${CFG}/Standalone.cfg

	read -p 'Enter the User Name : ' USER
	echo "USER="$USER"" >> ${CFG}/Standalone.cfg

	read -sp 'Enter the Password for the user name : ' PW
	echo "PW="$PW"" >> ${CFG}/Standalone.cfg
	
	export $(cat ${CFG}/Standalone.cfg | xargs)
	${SCR}/Operations.sh
	> ${CFG}/Standalone.cfg
	;;
    6 ) echo "You picked option $REPLY to perform the health check for $opt"
	read -p 'Enter the domain/environment name : ' env
        echo "env="$env"" >> ${CFG}/FT_Pair.cfg

        read -p 'Enter the first EMS URL : ' EMS1
        echo "EMS1="$EMS1"" >> ${CFG}/FT_Pair.cfg
	
	read -p 'Enter the second EMS URL : ' EMS2
        echo "EMS2="$EMS2"" >> ${CFG}/FT_Pair.cfg

        read -p 'Enter the User Name : ' USER
        echo "USER="$USER"" >> ${CFG}/FT_Pair.cfg

        read -sp 'Enter the Password for the user name : ' PW
        echo "PW="$PW"" >> ${CFG}/FT_Pair.cfg

        export $(cat ${CFG}/FT_Pair.cfg | xargs)
	${SCR}/Operations_FT.sh
	> ${CFG}/FT_Pair.cfg
	;;
    $(( ${#options[@]}+1 )) ) echo "Goodbye! See you soon :)"; break;;
    *) echo "Invalid option. Try another one.";continue;;

    esac

done

